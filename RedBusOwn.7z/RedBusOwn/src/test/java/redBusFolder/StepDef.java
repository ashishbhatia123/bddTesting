package redBusFolder;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
WebDriver driver;
@Given("^user is on Home page$")
public void user_is_on_Home_page() throws Throwable {
    
    /*id="src"
    id="dest"*/
	System.setProperty("webdriver.chrome.driver","D:\\BDD\\chromedriver_win32\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.get("https://www.redbus.in/");
}

@When("^want to travel from \"([^\"]*)\" to \"([^\"]*)\"$")
public void want_to_travel_from_to(String arg1, String arg2) throws Throwable {
driver.findElement(By.id("src")).sendKeys(arg1);
driver.findElement(By.id("dest")).sendKeys(arg2);
driver.findElement(By.className("db text-trans-uc move-up"))
}

@When("^user enters  todays date and return date (\\d+) days from today$")
public void user_enters_todays_date_and_return_date_days_from_today(int arg1) throws Throwable {
 
}

@Then("^navigate to view bus page$")
public void navigate_to_view_bus_page() throws Throwable {
    
}


}
