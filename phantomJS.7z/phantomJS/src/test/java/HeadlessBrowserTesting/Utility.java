package HeadlessBrowserTesting;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Utility {
public static void captureScreenShot(WebDriver driver , String screenShotName)
{
	try {
	TakesScreenshot ts = (TakesScreenshot) driver;
	File source = ts.getScreenshotAs(OutputType.FILE);
	
		FileUtils.copyFile(source, new File("./Screenshots/"+screenShotName+".png"));
	
	System.out.println("ScreenShot Taken");
}
	 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("exception while taking screen shorts"+ e.getMessage());
		}

}
}
